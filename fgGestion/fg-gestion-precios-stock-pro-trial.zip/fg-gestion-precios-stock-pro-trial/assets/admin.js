jQuery(document).ready(function($) {
    $('#btnLimpiar').on('click', function(e) {
        e.preventDefault();
        $('#sku').val('');
        $('#cat').val('all');
        $('#tipo').val('all');
        $('#miFormulario').submit();
    });

    $('.form-actualizar-producto').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        var row = form.closest('tr');
        var data = form.serialize();
        var btn = row.find('input[type="submit"], button[type="submit"]').first();
        var oldText = btn.val();

        btn.val('💾').prop('disabled', true);
        row.css('background-color', '#dbdbdb');

        $.post(ajaxurl, data, function(response) {
            if (response && response.success) {
                row.css('background-color', '#fbffa8');
                var celda = row.find('td').eq(8);
                var oferta = row.find('td').eq(4).find('input[type="number"]');
                var valor_oferta = oferta.val();
                var date_ini = row.find('td').eq(5).find('input[type="date"]');
                var date_fin = row.find('td').eq(6).find('input[type="date"]');

                if (!valor_oferta) {
                    date_ini.val('');
                    date_fin.val('');
                    celda.text('🔴Inactiva');
                } else {
                    celda.text('🟢Activa');
                }
            } else {
                alert('Error al guardar');
            }

            btn.val(oldText).prop('disabled', false);

        }).fail(function() {
            alert('Error al conectar con el servidor');
            btn.val(oldText).prop('disabled', false);
        });
    });

    $(document).on('click', '.toggle-featured', function(e) {
        e.preventDefault();
        var btn = $(this);
        var productId = btn.data('id');
        if (!productId) {
            alert('ID de producto inválido');
            return;
        }
        var oldText = btn.text();
        btn.prop('disabled', true).text('⏳...');

        $.post(ajaxurl, {
            action: 'fg_toggle_featured',
            id: productId
        }, function(response) {
            if (response && response.success) {
                var cls = response.data.class || '';
                var label = response.data.label || (response.data.featured ? '⭐ Destacado' : '❌ No destacado');
                btn.removeClass('btn-warning btn-secondary button-primary button-secondary')
                   .addClass(cls)
                   .text(label);
            } else {
                alert('Error: ' + (response.data || 'No se pudo cambiar el estado'));
                btn.text(oldText);
            }
        }).fail(function() {
            alert('Error de conexión con el servidor');
            btn.text(oldText);
        }).always(function() {
            btn.prop('disabled', false);
        });
    });
});
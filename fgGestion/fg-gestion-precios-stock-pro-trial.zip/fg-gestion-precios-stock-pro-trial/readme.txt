=== FG – Stock, Prices and Sales Management ===
Contributors: fabiangrasso
Tags: woocommerce, stock, inventory, price update, sale prices
Requires at least: 5.9
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple and efficient tool to manage WooCommerce stock, regular prices, sale prices, and sale dates based on SKU.

== Description ==

FG – Stock, Prices and Sales Management is a lightweight tool designed to simplify WooCommerce product maintenance, especially for stores that work with SKU-based inventories.

This plugin allows you to:

- Search products by SKU
- Update stock, regular price, and sale price
- Filter products by category or price type
- Automatically clean expired sale prices at midnight

**Note:** Sale date configuration is available in the Pro version of the plugin.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/fg-gestion-stock/` directory, or install it directly from the WordPress plugin repository.
2. Activate the plugin through the “Plugins” menu in WordPress.
3. Go to **WooCommerce → FG Stock Manager** and start using the tool.

== Frequently Asked Questions ==

= Does it work with variable products? =
Yes, as long as each variation has its own SKU.

= Are sale dates available in the free version? =
Sale date management (start and end dates) is available only in the Pro version.

= Does it delete existing sale prices? =
No. It only removes sale prices that have already expired.

== Screenshots ==
1. Product search by SKU.
2. Bulk stock and price editor interface.
3. Sale date configuration (Pro version).
4. Automatic expired sale cleanup settings.

== Changelog ==

= 2.1 =
* Improved interface and WooCommerce compatibility.
* Added automatic cleanup of expired sale prices.
* General stability improvements and minor bug fixes.

== Upgrade Notice ==
Recommended update for better WooCommerce compatibility and improved sale cleanup system.

